#include <rp6502.h>

int __fastcall__ phi2 (void)
{
    return ria_call_int (RIA_OP_PHI2);
}
